package sdp.jakdojde;

public class PierwszyFragmentTrasy extends FragmentTrasy{
    //is decorated by InnyFragmentTrasy class


private volatile static PierwszyFragmentTrasy instance;

    private InnyFragmentTrasy nastepnik;
    private PierwszyFragmentTrasy (){
        }

        public static PierwszyFragmentTrasy getInstance(){
            if (instance == null){
                synchronized (PierwszyFragmentTrasy.class){
                    if(instance==null){
                        instance = new PierwszyFragmentTrasy();
                    }
                }
            }
            return instance;
    }



}

package sdp.jakdojde;

public class Punkt {

    public boolean isCzyPoczatkowy() {
        return CzyPoczatkowy;
    }

    public void setCzyPoczatkowy(boolean czyPoczatkowy) {
        CzyPoczatkowy = czyPoczatkowy;
    }

    private boolean CzyPoczatkowy;

    public boolean isCzyKoncowy() {
        return CzyKoncowy;
    }

    public void setCzyKoncowy(boolean czyKoncowy) {
        CzyKoncowy = czyKoncowy;
    }

    private boolean CzyKoncowy;

    public double getLat() {
        return lat;
    }

    public void setLat(double lat) {
        this.lat = lat;
    }

    private double lat;

    public double getLon() {
        return lon;
    }

    public void setLon(double lon) {
        this.lon = lon;
    }

    private double lon;
}

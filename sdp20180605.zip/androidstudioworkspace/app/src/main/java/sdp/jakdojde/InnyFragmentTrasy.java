package sdp.jakdojde;

public class InnyFragmentTrasy extends FragmentTrasy {
    //implements decorator pattern

    InnyFragmentTrasy(FragmentTrasy poprzednik){

    }

    public FragmentTrasy getPoprzednik() {
        return poprzednik;
    }

    public void setPoprzednik(FragmentTrasy poprzednik) {
        this.poprzednik = poprzednik;
    }

    private FragmentTrasy poprzednik;
}

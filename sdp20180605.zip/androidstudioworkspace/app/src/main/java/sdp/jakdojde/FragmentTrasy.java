package sdp.jakdojde;

public abstract class FragmentTrasy {
    public Punkt getPoczatek() {
        return poczatek;
    }

    public void setPoczatek(Punkt poczatek) {
        this.poczatek = poczatek;
    }

    private Punkt poczatek;

    public Punkt getKoniec() {
        return koniec;
    }

    public void setKoniec(Punkt koniec) {
        this.koniec = koniec;
    }

    private Punkt koniec;

   /* public int getIndex() {
        return index;
    }

    public void setIndex(int index) {
        this.index = index;
    }

    private int index; */



}
